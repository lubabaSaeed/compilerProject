
package symboltable;
import java.util.Scanner;

public class SymbolTable {
    public static void main(String[] args) {
        String dataType[]= {"int","string","double","char","float"};
        String keyWords [] = {"for","function","if","var","while","else","do","switch","case","and",
            "begin","forward","div","end","array","mod","not","of","or","procedure","program","record","then","to","type"};
        int n;
        Scanner s = new Scanner(System.in);
        String table [][]= new String[][]{{"Key word","ID","Data Type","Initial Value"}};
        System.out.println("Enter input: ");
        String input ="";
        while (s.hasNext()){
        input+= s.nextLine() + " ";
        if (input.contains("print st")){
        break;
        }
        }
        String arr[]= input.split(" ");
        System.out.println("-------------------------------------------------------------------------------------------------------");
        for (int i =0; i<4;i++){
            System.out.print(table[0][i]+ " |  ");
        }
        System.out.println("");
        System.out.println("-------------------------------------------------------------------------------------------------------");
        int pos =1;
        for (int i =0; i<arr.length;i++){
            for (int k=0;k<keyWords.length;k++){
            if (arr[i].equals(keyWords[k])){
                 switch (arr[i]){
                     case "else" : 
                     case "do" : 
                     case "case": 
                     case "and":
                     case "begin": 
                     case "forward":
                     case "div": 
                     case "end": 
                     case "array":
                     case "mod": 
                     case "not":
                     case "of": 
                     case "or": 
                     case "procedure":
                     case "program":
                     case "record":
                     case "then": 
                     case "to":
                     case "type":
                     case "var" :
                     System.out.print("  "+arr[i]+"     ");
                         System.out.println(" ");      
                 }
            }}
            for (int j =0; j<dataType.length;j++){
              
                if (arr[0].equals(dataType[j])){
                  
                    switch (arr[i]){
                        case "=":{
                        pos=i;
                            System.out.print("           "+arr[pos-1]+"");// print id
                             System.out.print("      "+arr[pos-2]+"          "); //print datatype
                         
                            System.out.println(arr[pos+1]+"");// initial value
                    }
                        break;
                        case "(":{
                        pos = i;
                        n=i+1;
                            System.out.print("  "+arr[pos-1]+"     "); // print keyword
                            if(arr[pos+1].equals(")")){
                                System.out.println("            ");  
                            }
                            }
                            System.out.println("");
                        break;
                        default:
                            
                            break;
                }
            }
        }
    }
        
    
}
}